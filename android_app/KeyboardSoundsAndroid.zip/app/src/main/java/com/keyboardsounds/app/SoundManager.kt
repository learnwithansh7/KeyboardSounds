package com.keyboardsounds.app

import android.content.Context
import android.content.res.AssetFileDescriptor
import android.media.AudioAttributes
import android.media.SoundPool
import android.util.Log
import java.io.IOException
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.random.Random

class SoundManager(private val context: Context) {

    private val tag = "SoundManager"
    private var soundPool: SoundPool? = null

    private val keySounds = CopyOnWriteArrayList<Int>()
    private var spaceSoundId: Int? = null
    private var enterSoundId: Int? = null
    private var backspaceSoundId: Int? = null

    private var currentProfileFolder: String = "Cream"
    var volume: Float = 0.85f

    init {
        initSoundPool()
    }

    private fun initSoundPool() {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(16)
            .setAudioAttributes(audioAttributes)
            .build()
    }

    fun loadProfile(profileFolderName: String) {
        currentProfileFolder = profileFolderName
        val pool = soundPool ?: return

        // Clear existing sound mapping
        keySounds.clear()
        spaceSoundId = null
        enterSoundId = null
        backspaceSoundId = null

        val assetManager = context.assets
        val subDirs = listOf("sounds/$profileFolderName/down", "sounds/$profileFolderName")

        for (dir in subDirs) {
            try {
                val files = assetManager.list(dir) ?: continue
                if (files.isEmpty()) continue

                for (fileName in files) {
                    if (!fileName.endsWith(".wav", ignoreCase = true) &&
                        !fileName.endsWith(".mp3", ignoreCase = true) &&
                        !fileName.endsWith(".ogg", ignoreCase = true)) {
                        continue
                    }

                    val filePath = "$dir/$fileName"
                    try {
                        val afd: AssetFileDescriptor = assetManager.openFd(filePath)
                        val soundId = pool.load(afd, 1)
                        keySounds.add(soundId)

                        val lower = fileName.lowercase()
                        if (lower.contains("space")) {
                            spaceSoundId = soundId
                        } else if (lower.contains("enter") || lower.contains("return")) {
                            enterSoundId = soundId
                        } else if (lower.contains("backspace") || lower.contains("back")) {
                            backspaceSoundId = soundId
                        }
                    } catch (e: IOException) {
                        Log.w(tag, "Failed to load audio asset: $filePath", e)
                    }
                }

                if (keySounds.isNotEmpty()) {
                    break
                }
            } catch (e: Exception) {
                Log.e(tag, "Error reading sounds directory: $dir", e)
            }
        }

        Log.d(tag, "Loaded profile [$profileFolderName] with ${keySounds.size} sounds.")
    }

    fun playKeyDown() {
        if (keySounds.isEmpty()) return
        val soundId = keySounds[Random.nextInt(keySounds.size)]
        playSound(soundId)
    }

    fun playSpace() {
        val soundId = spaceSoundId ?: (if (keySounds.isNotEmpty()) keySounds[0] else null)
        soundId?.let { playSound(it) }
    }

    fun playEnter() {
        val soundId = enterSoundId ?: (if (keySounds.isNotEmpty()) keySounds[0] else null)
        soundId?.let { playSound(it) }
    }

    fun playBackspace() {
        val soundId = backspaceSoundId ?: (if (keySounds.isNotEmpty()) keySounds[0] else null)
        soundId?.let { playSound(it) }
    }

    private fun playSound(soundId: Int) {
        try {
            soundPool?.play(soundId, volume, volume, 1, 0, 1.0f)
        } catch (e: Exception) {
            Log.e(tag, "Error playing sound: $soundId", e)
        }
    }

    fun release() {
        soundPool?.release()
        soundPool = null
        keySounds.clear()
    }
}
