package com.keyboardsounds.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.accessibility.AccessibilityEvent
import androidx.preference.PreferenceManager

class TypingAccessibilityService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var soundManager: SoundManager
    private lateinit var prefs: SharedPreferences
    private var vibrator: Vibrator? = null

    private var isHapticsEnabled = true

    companion object {
        var isServiceRunning = false
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning = true

        soundManager = SoundManager(this)
        prefs = PreferenceManager.getDefaultSharedPreferences(this)
        prefs.registerOnSharedPreferenceChangeListener(this)

        initVibrator()
        loadPreferences()
    }

    private fun initVibrator() {
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    private fun loadPreferences() {
        val profileFolder = prefs.getString("selected_profile", "Cream") ?: "Cream"
        val volumePercent = prefs.getInt("volume_percent", 85)
        isHapticsEnabled = prefs.getBoolean("haptics_enabled", true)

        soundManager.volume = (volumePercent.coerceIn(0, 100) / 100f)
        soundManager.loadProfile(profileFolder)
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        loadPreferences()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            return
        }

        val addedCount = event.addedCount
        val removedCount = event.removedCount

        // 1. Keystroke Added
        if (addedCount > 0) {
            val text = event.text?.joinToString("") ?: ""
            val fromIndex = event.fromIndex
            val toIndex = (fromIndex + addedCount).coerceAtMost(text.length)

            val addedSegment = if (fromIndex in 0 until text.length && toIndex <= text.length) {
                text.substring(fromIndex, toIndex)
            } else {
                ""
            }

            when {
                addedSegment.contains("\n") -> soundManager.playEnter()
                addedSegment.contains(" ") -> soundManager.playSpace()
                else -> soundManager.playKeyDown()
            }

            performHapticClick()
        }
        // 2. Keystroke Removed (Backspace)
        else if (removedCount > 0) {
            soundManager.playBackspace()
            performHapticClick()
        }
    }

    private fun performHapticClick() {
        if (!isHapticsEnabled) return
        val v = vibrator ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                v.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(15)
            }
        } catch (_: Exception) {
        }
    }

    override fun onInterrupt() {
        // Required by AccessibilityService interface
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
        prefs.unregisterOnSharedPreferenceChangeListener(this)
        soundManager.release()
    }
}
